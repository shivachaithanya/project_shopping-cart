package com.niit.shoppingcart;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
public class Test 
{
public static void main(String[] args) {
	AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
	context.scan("com.niit.shoppingcart");
	context.refresh();
	System.out.println("cateogery is created");
	Product p=(Product) context.getBean("product");
	p.setId("PRD1");
	p.setName("I-PHONE");
	p.setPrice(400000.0);
	System.out.println(p.getId());
	System.out.println(p.getName());
	System.out.println(p.getPrice());
}
}
