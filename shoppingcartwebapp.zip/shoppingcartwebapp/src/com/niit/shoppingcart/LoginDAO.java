
package com.niit.shoppingcart;

public class LoginDAO 
{
public boolean isValidUser(String UserId,String Password)
{
	if(UserId.equals(Password))
	{
		return true;
	}
	else{
		return false;
	}
}
}
