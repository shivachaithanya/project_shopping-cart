package shoppingcart;

public class Department {
	private int id;
	public int getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	private String name;
	public Department(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
}
