package shoppingcart;

public class Employee {
	private String name; 
	private int id;
	private Employee manager;
	public Employee getManager() {
		return manager;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setManager(Employee manager) {
		this.manager = manager;
	}
	public Department getDept() {
		return dept;
	}
	public void setDept(Department dept) {
		this.dept = dept;
	}
	private Department dept;
	public Employee(String name, int id) 
	{
		this.name = name;
		this.id = id;
	}
	public static void main(String[] args) 
	{
		Employee manager=new Employee("shiva",102);
		Employee clerk =new Employee("ravi",105);
		clerk.setManager(manager);
		Department office=new Department(50,"office");
		clerk.setDept((office));
		display(clerk);
	}
	private static void display(Employee clerk) {
	System.out.println(clerk.getId());
System.out.println(clerk.getName());	
System.out.println(clerk.getManager().getName());
	System.out.println(clerk.getDept().getName());
	System.out.println(clerk.getDept().getId());
	}
	
	
	

}
