package shoppingcart;

import java.util.Collections;
import java.util.Comparator;

public class LinkedList {
	public static void main(String[] args) 
	{
		java.util.LinkedList<Emp1> list = new java.util.LinkedList<Emp1>();
		list.add(new Emp1("sim", 3000));
		list.add(new Emp1("tim", 4000));
		list.add(new Emp1("kim", 5000));
		list.add(new Emp1("rim", 6000));
	Collections.sort(list,new MySalaryComp());
		System.out.println(" ");
		for (Emp1 e : list) {
			System.out.println(e);
		}
	}
}

class Emp1
{
	private String name;
	private int salary;
	public Emp1(String n,int s)
	{
		this.name=n;
		this.salary=s;
		}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public String toString(){
		return  "Name :"+this.name+"--salary:"+this.salary;
	}
	}
class MySalaryComp implements Comparator<Emp1>
{
	public int compare(Emp1 e1,Emp1 e2)
	{
		if(e1.getSalary() < e2.getSalary())
		{
			return 1;
		}
		else{
			return -1;
		}
	}
	}
	