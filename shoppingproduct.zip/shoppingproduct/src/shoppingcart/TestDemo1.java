package shoppingcart;
import java.util.ArrayList;
public class TestDemo1 {
	public static void main(String[] args) 
	{
		ArrayList<Product> products = new ArrayList<Product>();
		Product p = new Product("PRD1","IPHONE",12000.0);
        products.add(p);
        p=new Product("PRD2","MOTOE",15000.0);
        products.add(p);
        p=new Product("PRD3","SAMSUNG",12000.0);
        products.add(p);
        for(Product prd:products)
        {
        	System.out.println(prd.getId());
        	System.out.println(prd.getName());
        	System.out.println(prd.getPrice());	
        	
        }
        
	}
	
}
