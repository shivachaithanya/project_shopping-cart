package com.niit.demo.dao;

import java.util.List;

import com.niit.demo.model.Employee;

public interface EmployeeDao 
{
	public List<Employee> getAllEmployees();
}
