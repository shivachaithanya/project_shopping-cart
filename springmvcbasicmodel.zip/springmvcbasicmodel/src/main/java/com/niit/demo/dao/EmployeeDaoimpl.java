package com.niit.demo.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.niit.demo.model.Employee;

@Repository
public class EmployeeDaoimpl implements EmployeeDao
{

	public List<Employee> getAllEmployees() {
	
List<Employee> employees = new ArrayList<Employee>();
		
		Employee e1= new Employee();
		e1.setId(1);
		e1.setFirstName("Lokesh");
		e1.setLastName("Gupta");
		employees.add(e1);
		
		Employee e2 = new Employee();
		e2.setId(2);
		e2.setFirstName("Raj");
		e2.setLastName("Kishore");
		employees.add(e2);
		return employees;
	}

}
