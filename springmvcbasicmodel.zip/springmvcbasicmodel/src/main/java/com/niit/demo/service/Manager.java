package com.niit.demo.service;

import java.util.List;

import com.niit.demo.model.Employee;

public interface Manager 
{
public List<Employee> getAllEmployees();
}
