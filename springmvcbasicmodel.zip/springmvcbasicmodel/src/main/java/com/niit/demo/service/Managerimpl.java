package com.niit.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.niit.demo.dao.EmployeeDao;
import com.niit.demo.model.Employee;

@Service
public class Managerimpl implements Manager
{
	@Autowired
	EmployeeDao dao;
	
	public List<Employee> getAllEmployees() {
	
		return dao.getAllEmployees();
	}

}
